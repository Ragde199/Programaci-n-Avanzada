package com.pventa.controller;

import com.pventa.dao.SaleDAO;
import com.pventa.model.Sale;
import java.sql.SQLException;
import java.util.List;

public class SaleController {
    private SaleDAO saleDAO;

    public SaleController() {
        this.saleDAO = new SaleDAO();
    }

    public void processSale(Sale sale) throws SQLException {
        saleDAO.insert(sale);
    }

    public Sale findSale(int id) throws SQLException {
        return saleDAO.findById(id);
    }

    public List<Sale> getAllSales() throws SQLException {
        return saleDAO.findAll();
    }

    public void deleteAllSales() throws SQLException {
        saleDAO.deleteAll();
    }
}
