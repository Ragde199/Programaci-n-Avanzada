package com.pventa.controller;

import com.pventa.dao.CategoryDAO;
import com.pventa.model.Category;
import java.sql.SQLException;
import java.util.List;

public class CategoryController {
    private CategoryDAO categoryDAO;

    public CategoryController() {
        this.categoryDAO = new CategoryDAO();
    }

    public void saveCategory(Category category) throws SQLException {
        if (category.getId() == 0) {
            categoryDAO.insert(category);
        } else {
            categoryDAO.update(category);
        }
    }

    public void deleteCategory(int id) throws SQLException {
        categoryDAO.delete(id);
    }

    public Category findCategory(int id) throws SQLException {
        return categoryDAO.findById(id);
    }

    public List<Category> getAllCategories() throws SQLException {
        return categoryDAO.findAll();
    }
}
