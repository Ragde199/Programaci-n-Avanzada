package com.pventa.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {    private static final String URL = "jdbc:sqlserver://EdgarRH\\SQLEXPRESS;databaseName=PVentaDB;integratedSecurity=false;trustServerCertificate=true;encrypt=false";
    private static final String USER = "sa";  // SQL Server Authentication
    private static final String PASSWORD = "admin123"; // SQL Server Authentication password
      private static DatabaseConnection instance;
    
    private DatabaseConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }
    
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
