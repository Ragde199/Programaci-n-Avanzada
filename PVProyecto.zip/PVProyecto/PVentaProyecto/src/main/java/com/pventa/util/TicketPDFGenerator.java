package com.pventa.util;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.pventa.model.Sale;
import com.pventa.model.SaleItem;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TicketPDFGenerator {
    public static void generateTicket(Sale sale, String filePath) throws Exception {
        Document document = new Document(PageSize.A6);
        PdfWriter.getInstance(document, new FileOutputStream(filePath));
        document.open();

        // Fuentes
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
        Font normalFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
        Font smallFont = new Font(Font.FontFamily.HELVETICA, 8, Font.NORMAL);
        Font totalFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);

        // Título
        Paragraph title = new Paragraph("TICKET DE VENTA", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        document.add(Chunk.NEWLINE);

        // Fecha y hora
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        Paragraph date = new Paragraph("Fecha: " + now.format(formatter), normalFont);
        date.setAlignment(Element.ALIGN_CENTER);
        document.add(date);
        document.add(Chunk.NEWLINE);

        // Tabla de productos
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{1, 3, 1, 1});

        // Encabezados de tabla
        String[] headers = {"Cant", "Producto", "P.U.", "Total"};
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, smallFont));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBorder(Rectangle.BOTTOM);
            table.addCell(cell);
        }

        // Contenido de la tabla
        for (SaleItem item : sale.getItems()) {
            // Cantidad
            PdfPCell cell = new PdfPCell(new Phrase(String.valueOf(item.getQuantity()), smallFont));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);

            // Producto
            cell = new PdfPCell(new Phrase(item.getProduct().getName(), smallFont));
            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);

            // Precio unitario
            cell = new PdfPCell(new Phrase(String.format("$%.2f", item.getProduct().getPrice()), smallFont));
            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);

            // Subtotal
            cell = new PdfPCell(new Phrase(String.format("$%.2f", item.getQuantity() * item.getProduct().getPrice()), smallFont));
            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);
        }

        document.add(table);
        document.add(Chunk.NEWLINE);

        // Total
        Paragraph total = new Paragraph(String.format("Total: $%.2f", sale.getTotal()), totalFont);
        total.setAlignment(Element.ALIGN_RIGHT);
        document.add(total);

        // Efectivo
        Paragraph cash = new Paragraph(String.format("Efectivo: $%.2f", sale.getCashReceived()), normalFont);
        cash.setAlignment(Element.ALIGN_RIGHT);
        document.add(cash);

        // Cambio
        Paragraph change = new Paragraph(String.format("Cambio: $%.2f", sale.getChange()), totalFont);
        change.setAlignment(Element.ALIGN_RIGHT);
        document.add(change);

        document.add(Chunk.NEWLINE);

        // Mensaje de agradecimiento
        Paragraph thanks = new Paragraph("¡Gracias por su compra!", normalFont);
        thanks.setAlignment(Element.ALIGN_CENTER);
        document.add(thanks);

        document.close();
    }
}
