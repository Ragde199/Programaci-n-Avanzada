package com.pventa.controller;

import com.pventa.dao.ProductDAO;
import com.pventa.model.Product;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;

public class ProductController {
    private ProductDAO productDAO;

    public ProductController() {
        this.productDAO = new ProductDAO();
    }

    public void saveProduct(Product product) throws SQLException {
        if (product.getId() == 0) {
            productDAO.insert(product);
        } else {
            productDAO.update(product);
        }
    }

    public void deleteProduct(int id) throws SQLException {
        productDAO.delete(id);
    }

    public Product findProduct(int id) throws SQLException {
        return productDAO.findById(id);
    }

    public Product findProductByBarcode(String barcode) throws SQLException {
        return productDAO.findByBarcode(barcode);
    }

    public List<Product> getAllProducts() throws SQLException {
        return productDAO.findAll();
    }

    public List<Product> getLowStockProducts(int threshold) throws SQLException {
        List<Product> allProducts = getAllProducts();
        return allProducts.stream()
                .filter(product -> product.getStock() < threshold)
                .collect(Collectors.toList());
    }

    public List<Product> searchProducts(String query) throws SQLException {
        return productDAO.searchProducts(query);
    }
}
