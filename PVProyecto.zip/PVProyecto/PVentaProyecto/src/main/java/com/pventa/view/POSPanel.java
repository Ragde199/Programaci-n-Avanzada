package com.pventa.view;

import com.pventa.controller.ProductController;
import com.pventa.controller.SaleController;
import com.pventa.model.Product;
import com.pventa.model.Sale;
import com.pventa.model.SaleItem;
import com.pventa.util.UIConstants;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.io.File;
import java.util.List;
import java.util.Vector;

public class POSPanel extends JPanel {    private JTable cartTable;
    private DefaultTableModel cartTableModel;
    private JLabel totalLabel;
    private JButton processButton;
    private JButton cancelButton;
    private Sale currentSale;
    private ProductController productController;
    private SaleController saleController;
    private DecimalFormat formatter;
    private ReportsPanel reportsPanel;
    private ProductListPanel productListPanel;
    private JTextField searchField;
    private JList<Product> searchResults;
    private DefaultListModel<Product> searchModel;

    public POSPanel(ReportsPanel reportsPanel) {
        this.reportsPanel = reportsPanel;
        productController = new ProductController();
        saleController = new SaleController();
        formatter = new DecimalFormat("#,##0.00");
        currentSale = new Sale();
        productListPanel = new ProductListPanel();
        
        initializeComponents();
        createLayout();
        setupListeners();
    }    private void initializeComponents() {

        String[] columnNames = {"Código", "Producto", "Cantidad", "Precio", "Subtotal"};
        cartTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2; // Solo permite editar la cantidad
            }
            
            @Override
            public void setValueAt(Object value, int row, int col) {
                if (col == 2) { // Si es la columna de cantidad
                    try {
                        int cantidad = Integer.parseInt(value.toString());
                        if (cantidad <= 0) {
                            JOptionPane.showMessageDialog(null, 
                                "La cantidad debe ser mayor a 0",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        super.setValueAt(cantidad, row, col);
                        // Actualizar subtotal
                        double precio = Double.parseDouble(getValueAt(row, 3).toString().replace(",", ""));
                        double subtotal = precio * cantidad;
                        super.setValueAt(formatter.format(subtotal), row, 4);
                        updateSaleTotal();
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null,
                            "Por favor ingrese un número válido",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    super.setValueAt(value, row, col);
                }
            }
        };

        cartTable = new JTable(cartTableModel);
        UIConstants.styleTable(cartTable);
        cartTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cartTable.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Configurar el editor personalizado para la columna de cantidad
        DefaultCellEditor quantityEditor = new DefaultCellEditor(new JTextField()) {
            @Override
            public boolean stopCellEditing() {
                try {
                    int cantidad = Integer.parseInt(getCellEditorValue().toString());
                    if (cantidad <= 0) {
                        JOptionPane.showMessageDialog(cartTable,
                            "La cantidad debe ser mayor a 0",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                        return false;
                    }
                    return super.stopCellEditing();
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(cartTable,
                        "Por favor ingrese un número válido",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }
        };
        cartTable.getColumnModel().getColumn(2).setCellEditor(quantityEditor);
        
        // Configurar Enter key para finalizar edición y mover foco
        cartTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        
        cartTable.getInputMap(JTable.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(
            KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
            "stopEditing");
              cartTable.getActionMap().put("stopEditing", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if (cartTable.isEditing()) {
                    cartTable.getCellEditor().stopCellEditing();
                }
            }
        });
        
        totalLabel = new JLabel("Total: $0.00");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 24));
        totalLabel.setForeground(UIConstants.ACCENT_RED);        processButton = new JButton("Procesar Venta");
        processButton.setFont(new Font("Arial", Font.BOLD, 16));
        UIConstants.styleButton(processButton);
        
        cancelButton = new JButton("Cancelar");
        cancelButton.setFont(new Font("Arial", Font.BOLD, 16));
        UIConstants.styleButton(cancelButton);

        // Componentes para el sistema de búsqueda
        searchField = new JTextField(20);
        searchField.setFont(new Font("Arial", Font.PLAIN, 16));
        searchModel = new DefaultListModel<>();
        searchResults = new JList<>(searchModel);
        searchResults.setFont(new Font("Arial", Font.PLAIN, 16));
        searchResults.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }    private void createLayout() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setBackground(UIConstants.LIGHT_GRAY);

        // Panel principal dividido en dos partes
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setResizeWeight(0.7); // 70% izquierda, 30% derecha
        
        // Panel izquierdo (carrito)
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBackground(UIConstants.LIGHT_GRAY);        // Panel superior solo para búsqueda
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.setBackground(UIConstants.LIGHT_GRAY);
        
        // Panel de búsqueda
        topPanel.add(createSearchPanel(), BorderLayout.CENTER);
        
        leftPanel.add(topPanel, BorderLayout.NORTH);// Panel central para la tabla de productos con borde y padding
        JScrollPane scrollPane = new JScrollPane(cartTable);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(5, 5, 5, 5),
            BorderFactory.createLineBorder(UIConstants.SECONDARY_GRAY)
        ));
        leftPanel.add(scrollPane, BorderLayout.CENTER);

        // Panel inferior para el total y botones con estilo consistente
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBackground(UIConstants.LIGHT_GRAY);
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonsPanel.setBackground(UIConstants.LIGHT_GRAY);
        buttonsPanel.add(cancelButton);
        buttonsPanel.add(processButton);
        
        bottomPanel.add(totalLabel, BorderLayout.WEST);
        bottomPanel.add(buttonsPanel, BorderLayout.EAST);
        leftPanel.add(bottomPanel, BorderLayout.SOUTH);

        // Configurar el split pane
        splitPane.setLeftComponent(leftPanel);
        splitPane.setRightComponent(productListPanel);
        
        add(splitPane, BorderLayout.CENTER);
    }    private void setupListeners() {
        // Agregar listener para cambios en la tabla
        cartTable.getModel().addTableModelListener(e -> {
            if (e.getType() == javax.swing.event.TableModelEvent.UPDATE && e.getColumn() == 2) {
                int row = e.getFirstRow();
                try {
                    int cantidad = Integer.parseInt(cartTableModel.getValueAt(row, 2).toString());
                    double precio = Double.parseDouble(cartTableModel.getValueAt(row, 3).toString().replace(",", ""));
                    double subtotal = cantidad * precio;
                    cartTableModel.setValueAt(formatter.format(subtotal), row, 4);
                    updateSaleTotal();

                    // Actualizar el item en la venta actual
                    SaleItem item = currentSale.getItems().get(row);
                    item.setQuantity(cantidad);
                } catch (NumberFormatException ex) {
                    // Error ya manejado por el editor de celda
                }
            }
        });        // Se eliminó el manejo del campo de código de barras

        processButton.addActionListener(e -> processSale());
        cancelButton.addActionListener(e -> cancelSale());

        // Listener para el campo de búsqueda
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateSearchResults();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateSearchResults();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateSearchResults();
            }
        });        // Removed automatic product addition on selection
    }

    private void addProductToCart(Product product) {
        // Buscar si el producto ya está en el carrito
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            if (cartTableModel.getValueAt(i, 0).toString().equals(product.getBarcode())) {
                int currentQuantity = Integer.parseInt(cartTableModel.getValueAt(i, 2).toString());
                cartTableModel.setValueAt(currentQuantity + 1, i, 2);
                updateSaleTotal();
                return;
            }
        }

        // Si no está en el carrito, agregar nueva fila
        Vector<Object> row = new Vector<>();
        row.add(product.getBarcode());
        row.add(product.getName());
        row.add(1); // Cantidad inicial
        row.add(formatter.format(product.getPrice()));
        row.add(formatter.format(product.getPrice()));

        cartTableModel.addRow(row);
        
        SaleItem item = new SaleItem(product, 1);
        currentSale.addItem(item);
        updateSaleTotal();
    }

    private void updateSaleTotal() {
        double total = 0;
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            int quantity = Integer.parseInt(cartTableModel.getValueAt(i, 2).toString());
            double price = Double.parseDouble(cartTableModel.getValueAt(i, 3).toString().replace(",", ""));
            total += quantity * price;
            cartTableModel.setValueAt(formatter.format(quantity * price), i, 4);
        }
        totalLabel.setText("Total: $" + formatter.format(total));
    }    private void processSale() {
        if (cartTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, 
                "El carrito está vacío", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Solicitar el dinero recibido
        String input = JOptionPane.showInputDialog(this,
            "Total a pagar: $" + formatter.format(currentSale.getTotal()) + "\n" +
            "Ingrese el monto recibido:",
            "Procesar Pago",
            JOptionPane.QUESTION_MESSAGE);

        if (input == null) {
            return; // Usuario canceló
        }

        try {
            double cashReceived = Double.parseDouble(input.replace(",", ""));
            if (cashReceived < currentSale.getTotal()) {
                JOptionPane.showMessageDialog(this,
                    "El monto recibido es insuficiente",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            currentSale.setCashReceived(cashReceived);

            // Mostrar el cambio
            JOptionPane.showMessageDialog(this,
                "Cambio a entregar: $" + formatter.format(currentSale.getChange()),
                "Cambio",
                JOptionPane.INFORMATION_MESSAGE);

            // Procesar la venta
            saleController.processSale(currentSale);
            reportsPanel.updateReports();

            // Generar y mostrar el ticket
            String ticketPath = String.format("tickets/ticket_%d.pdf", currentSale.getId());
            File ticketDir = new File("tickets");
            if (!ticketDir.exists()) {
                ticketDir.mkdirs();
            }

            // Generar el PDF del ticket
            try {
                com.pventa.util.TicketPDFGenerator.generateTicket(currentSale, ticketPath);
                JOptionPane.showMessageDialog(this,
                    "Ticket guardado en: " + ticketPath,
                    "Ticket PDF Generado",
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,
                    "Error al generar el PDF del ticket: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }

            showTicket(); // Mostrar el ticket en pantalla
            clearSale();
            productListPanel.loadProducts(); // Actualizar lista de productos

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Por favor ingrese un monto válido",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void cancelSale() {
        if (cartTableModel.getRowCount() > 0) {
            int response = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de cancelar la venta actual?",
                "Confirmar Cancelación",
                JOptionPane.YES_NO_OPTION);
                
            if (response == JOptionPane.YES_OPTION) {
                clearSale();
            }
        }
    }    private void clearSale() {
        cartTableModel.setRowCount(0);
        currentSale = new Sale();
        totalLabel.setText("Total: $0.00");
        searchField.setText("");
        searchField.requestFocus();
    }private void showTicket() {
        JDialog ticketDialog = new JDialog((Frame)SwingUtilities.getWindowAncestor(this), "Ticket de Venta", true);
        ticketDialog.setLayout(new BorderLayout(10, 10));
        ticketDialog.setSize(400, 500);
        ticketDialog.setLocationRelativeTo(null);

        // Panel para el contenido del ticket con estilo moderno
        JPanel ticketPanel = new JPanel();
        ticketPanel.setLayout(new BoxLayout(ticketPanel, BoxLayout.Y_AXIS));
        ticketPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        ticketPanel.setBackground(UIConstants.LIGHT_GRAY);

        // Encabezado del ticket con estilo
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(UIConstants.LIGHT_GRAY);
        headerPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        JLabel headerLabel = new JLabel("TICKET DE VENTA");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setForeground(UIConstants.ACCENT_RED);
        headerPanel.add(headerLabel);
        ticketPanel.add(headerPanel);
        
        ticketPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Fecha y hora
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        datePanel.setBackground(UIConstants.LIGHT_GRAY);
        datePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
        JLabel dateLabel = new JLabel("Fecha: " + java.time.LocalDateTime.now().format(
            java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
        dateLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        datePanel.add(dateLabel);
        ticketPanel.add(datePanel);

        ticketPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Tabla del ticket con estilo consistente
        String[] columnNames = {"Cant", "Producto", "P.U.", "Total"};
        DefaultTableModel ticketTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable ticketTable = new JTable(ticketTableModel);
        UIConstants.styleTable(ticketTable);
        ticketTable.setFont(new Font("Arial", Font.PLAIN, 12));
        ticketTable.setEnabled(false);
        ticketTable.setShowGrid(false);
        
        // Llenar la tabla con los productos
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            Vector<Object> row = new Vector<>();
            row.add(cartTableModel.getValueAt(i, 2)); // Cantidad
            row.add(cartTableModel.getValueAt(i, 1)); // Nombre del producto
            row.add(cartTableModel.getValueAt(i, 3)); // Precio unitario
            row.add(cartTableModel.getValueAt(i, 4)); // Subtotal
            ticketTableModel.addRow(row);
        }

        JScrollPane ticketScrollPane = new JScrollPane(ticketTable);
        ticketScrollPane.setPreferredSize(new Dimension(350, 200));
        ticketPanel.add(ticketScrollPane);

        ticketPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Totales con estilo consistente
        JPanel totalsPanel = new JPanel();
        totalsPanel.setLayout(new BoxLayout(totalsPanel, BoxLayout.Y_AXIS));
        totalsPanel.setBackground(UIConstants.LIGHT_GRAY);
        totalsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        totalsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Total
        JLabel totalTicketLabel = new JLabel("Total: $" + formatter.format(currentSale.getTotal()));
        totalTicketLabel.setFont(new Font("Arial", Font.BOLD, 16));
        totalTicketLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        totalTicketLabel.setForeground(UIConstants.ACCENT_RED);
        totalsPanel.add(totalTicketLabel);

        // Efectivo recibido
        JLabel cashLabel = new JLabel("Efectivo: $" + formatter.format(currentSale.getCashReceived()));
        cashLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        cashLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        totalsPanel.add(cashLabel);

        // Cambio
        JLabel changeLabel = new JLabel("Cambio: $" + formatter.format(currentSale.getChange()));
        changeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        changeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        totalsPanel.add(changeLabel);

        ticketPanel.add(totalsPanel);

        ticketPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Mensaje de agradecimiento con estilo
        JPanel thanksPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        thanksPanel.setBackground(UIConstants.LIGHT_GRAY);
        thanksPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        JLabel thanksLabel = new JLabel("¡Gracias por su compra!");
        thanksLabel.setFont(new Font("Arial", Font.BOLD, 14));
        thanksPanel.setForeground(UIConstants.PRIMARY_RED);
        thanksPanel.add(thanksLabel);
        ticketPanel.add(thanksPanel);

        JScrollPane dialogScrollPane = new JScrollPane(ticketPanel);
        dialogScrollPane.setBackground(UIConstants.LIGHT_GRAY);
        ticketDialog.add(dialogScrollPane, BorderLayout.CENTER);
        ticketDialog.setVisible(true);
    }

    private void handleDatabaseError(SQLException ex) {
        JOptionPane.showMessageDialog(this,
            "Error de base de datos: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }    private void updateSearchResults() {
        String query = searchField.getText().trim().toLowerCase();
        searchModel.clear();

        if (!query.isEmpty()) {
            try {
                List<Product> products = productController.searchProducts(query);
                for (Product product : products) {
                    if (product.getStock() > 0) {  // Solo mostrar productos con stock disponible
                        searchModel.addElement(product);
                    }
                }
                if (!searchModel.isEmpty()) {
                    searchResults.setSelectedIndex(0);
                }
            } catch (SQLException e) {
                handleDatabaseError(e);
            }
        }
    }
      private JPanel createSearchPanel() {
        JPanel searchPanel = new JPanel(new BorderLayout(5, 5));
        searchPanel.setBackground(UIConstants.LIGHT_GRAY);
        
        // Campo de búsqueda con autocompletado
        searchField = new JTextField(20);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        searchModel = new DefaultListModel<>();
        searchResults = new JList<>(searchModel);
        searchResults.setVisibleRowCount(5);
        searchResults.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Estilizar la lista de resultados
        searchResults.setBackground(Color.WHITE);
        searchResults.setFont(new Font("Arial", Font.PLAIN, 14));
        searchResults.setBorder(BorderFactory.createLineBorder(UIConstants.SECONDARY_GRAY));
        
        // Configurar el renderizado de los productos en la lista
        searchResults.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Product) {
                    Product product = (Product) value;
                    setText(String.format("%-30s $%-8.2f (%d en stock)", 
                        product.getName(), 
                        product.getPrice(),
                        product.getStock()));
                    setFont(new Font("Monospace", Font.PLAIN, 14));
                }
                return this;
            }
        });

        // Actualizar búsqueda mientras se escribe
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { updateSearchResults(); }
            public void removeUpdate(DocumentEvent e) { updateSearchResults(); }
            public void insertUpdate(DocumentEvent e) { updateSearchResults(); }
        });

        // Botón de agregar al carrito
        JButton addButton = new JButton("Agregar al Carrito");
        UIConstants.styleButton(addButton);
        addButton.setEnabled(false);
        addButton.setFont(new Font("Arial", Font.BOLD, 14));

        // Habilitar botón solo cuando hay selección
        searchResults.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                addButton.setEnabled(!searchResults.isSelectionEmpty());
            }
        });

        // Agregar producto al carrito
        addButton.addActionListener(e -> {
            Product selected = searchResults.getSelectedValue();
            if (selected != null) {
                addProductToCart(selected);
                searchField.setText("");
                searchModel.clear();
                addButton.setEnabled(false);
                searchField.requestFocus();
            }
        });

        // Scroll para los resultados
        JScrollPane scrollPane = new JScrollPane(searchResults);
        scrollPane.setPreferredSize(new Dimension(400, 150));

        // Panel del campo de búsqueda
        JPanel searchFieldPanel = new JPanel(new BorderLayout(5, 5));
        searchFieldPanel.setBackground(UIConstants.LIGHT_GRAY);
        
        JLabel searchLabel = new JLabel("Buscar Producto:");
        searchLabel.setFont(new Font("Arial", Font.BOLD, 14));
        searchLabel.setForeground(UIConstants.ACCENT_RED);
        
        searchFieldPanel.add(searchLabel, BorderLayout.NORTH);
        searchFieldPanel.add(searchField, BorderLayout.CENTER);

        // Panel del botón
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(UIConstants.LIGHT_GRAY);
        buttonPanel.add(addButton);        // Organizar los componentes
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.setBackground(UIConstants.LIGHT_GRAY);
        topPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
        topPanel.add(searchFieldPanel, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.EAST);

        searchPanel.add(topPanel, BorderLayout.NORTH);
        searchPanel.add(scrollPane, BorderLayout.CENTER);

        return searchPanel;    }
}
