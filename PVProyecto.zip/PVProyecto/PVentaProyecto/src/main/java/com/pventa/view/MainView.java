package com.pventa.view;

import com.pventa.util.UIConstants;
import javax.swing.*;
import java.awt.*;

public class MainView extends JFrame {    private JMenuBar menuBar;
    private POSPanel posPanel;
    private ProductManagementPanel productPanel;
    private CategoryManagementPanel categoryPanel;
    private ReportsPanel reportsPanel;
    private CardLayout cardLayout;
    private JPanel mainPanel;

    public MainView() {
        setTitle("Sistema de Punto de Venta");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        getContentPane().setBackground(UIConstants.LIGHT_GRAY);

        initializeComponents();
        createLayout();
        createMenuBar();
    }

    public ReportsPanel getReportsPanel() {
        return reportsPanel;
    }    private void initializeComponents() {        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.setBackground(UIConstants.LIGHT_GRAY);
        
        reportsPanel = new ReportsPanel();
        posPanel = new POSPanel(reportsPanel);
        productPanel = new ProductManagementPanel();
        categoryPanel = new CategoryManagementPanel();

        mainPanel.add(posPanel, "POS");
        mainPanel.add(productPanel, "INVENTORY");
        mainPanel.add(categoryPanel, "CATEGORIES");
        mainPanel.add(reportsPanel, "REPORTS");
    }

    private void createLayout() {
        setLayout(new BorderLayout());
        add(mainPanel, BorderLayout.CENTER);
    }

    private void createMenuBar() {        menuBar = new JMenuBar();
        menuBar.setBackground(UIConstants.PRIMARY_RED);
        
        JMenu systemMenu = new JMenu("Sistema");
        systemMenu.setForeground(Color.BLACK);          // Crear items del menú
        JMenuItem[] items = {
            new JMenuItem("Punto de Venta"),
            new JMenuItem("Inventario"),
            new JMenuItem("Categorías"),
            new JMenuItem("Reportes")
        };

        String[] cardNames = {"POS", "INVENTORY", "CATEGORIES", "REPORTS"};

        // Configurar cada item
        for (int i = 0; i < items.length; i++) {
            JMenuItem item = items[i];
            String cardName = cardNames[i];
            
            item.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            configureMenuItem(item, UIConstants.LIGHT_GRAY, Color.BLACK);
              item.addActionListener(e -> {
                cardLayout.show(mainPanel, cardName);
                if (cardName.equals("INVENTORY")) {
                    productPanel.loadCategories();
                }
            });
            systemMenu.add(item);
        }

        // Agregar separador y botón de salir
        systemMenu.addSeparator();
        JMenuItem exitMenuItem = new JMenuItem("Salir");
        configureMenuItem(exitMenuItem, UIConstants.LIGHT_GRAY, Color.BLACK);
        exitMenuItem.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        exitMenuItem.addActionListener(e -> System.exit(0));
        systemMenu.add(exitMenuItem);

        menuBar.add(systemMenu);
        setJMenuBar(menuBar);
    }

    private void configureMenuItem(JMenuItem item, Color bg, Color fg) {
        item.setBackground(bg);
        item.setForeground(fg);
        item.setOpaque(true);
        // Agregar efecto hover
        item.addChangeListener(e -> {
            if (item.isArmed()) {
                item.setBackground(UIConstants.ACCENT_RED);
                item.setForeground(Color.WHITE);
            } else {
                item.setBackground(bg);
                item.setForeground(fg);
            }
        });
    }
}
