package com.pventa.view;

import com.pventa.controller.ProductController;
import com.pventa.controller.CategoryController;
import com.pventa.model.Product;
import com.pventa.model.Category;
import com.pventa.util.UIConstants;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;

public class ProductManagementPanel extends JPanel {
    private JTable productTable;
    private DefaultTableModel tableModel;
    private ProductController productController;
    private CategoryController categoryController;
    private DecimalFormat formatter;
    private JTextField idField;
    private JTextField nameField;
    private JTextField descriptionField;
    private JTextField priceField;
    private JTextField stockField;
    private JTextField barcodeField;
    private JComboBox<Category> categoryComboBox;
    private JButton saveButton;
    private JButton deleteButton;
    private JButton clearButton;
    private JButton modifyStockButton;

    public ProductManagementPanel() {
        productController = new ProductController();
        categoryController = new CategoryController();
        formatter = new DecimalFormat("#,##0.00");

        initializeComponents();
        createLayout();
        setupListeners();
        loadCategories();
        loadProducts();
        
        // Aplicar colores al panel principal
        setBackground(UIConstants.LIGHT_GRAY);
    }

    public void loadCategories() {
        try {
            List<Category> categories = categoryController.getAllCategories();
            categoryComboBox.removeAllItems();
            categoryComboBox.addItem(null); // Opción sin categoría
            for (Category category : categories) {
                categoryComboBox.addItem(category);
            }
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void initializeComponents() {
        String[] columnNames = {"ID", "Código", "Nombre", "Descripción", "Precio", "Stock", "Categoría"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        productTable = new JTable(tableModel);
        productTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        productTable.getTableHeader().setReorderingAllowed(false);
        UIConstants.styleTable(productTable);

        idField = new JTextField(10);
        idField.setEditable(false);
        nameField = new JTextField(20);
        descriptionField = new JTextField(30);
        priceField = new JTextField(10);
        stockField = new JTextField(10);
        barcodeField = new JTextField(15);
        categoryComboBox = new JComboBox<>();        // Botones
        saveButton = new JButton("Guardar");
        deleteButton = new JButton("Eliminar");
        clearButton = new JButton("Limpiar");
        modifyStockButton = new JButton("Modificar Stock");

        // Aplicar estilo a los botones
        UIConstants.styleButton(saveButton);
        UIConstants.styleButton(deleteButton);
        UIConstants.styleButton(clearButton);
        UIConstants.styleButton(modifyStockButton);
    }

    private void createLayout() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel de título
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titlePanel.setBackground(UIConstants.LIGHT_GRAY);        JLabel titleLabel = new JLabel("Gestión de Productos", SwingConstants.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(UIConstants.ACCENT_RED);
        titlePanel.add(titleLabel);

        // Form Panel con fondo
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(UIConstants.LIGHT_GRAY);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Labels con color
        JLabel idLabel = new JLabel("ID:");        JLabel barcodeLabel = new JLabel("Código", SwingConstants.LEFT);
        JLabel nameLabel = new JLabel("Nombre:");
        JLabel descLabel = new JLabel("Descripción:");
        JLabel priceLabel = new JLabel("Precio:");
        JLabel stockLabel = new JLabel("Stock", SwingConstants.LEFT);
        JLabel categoryLabel = new JLabel("Categoría", SwingConstants.LEFT);

        idLabel.setForeground(UIConstants.ACCENT_RED);
        barcodeLabel.setForeground(UIConstants.ACCENT_RED);
        nameLabel.setForeground(UIConstants.ACCENT_RED);
        descLabel.setForeground(UIConstants.ACCENT_RED);
        priceLabel.setForeground(UIConstants.ACCENT_RED);
        stockLabel.setForeground(UIConstants.ACCENT_RED);
        categoryLabel.setForeground(UIConstants.ACCENT_RED);

        // Primera fila
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(idLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(idField, gbc);

        gbc.gridx = 2;
        formPanel.add(barcodeLabel, gbc);
        gbc.gridx = 3;
        formPanel.add(barcodeField, gbc);

        // Segunda fila
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(nameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 3;
        formPanel.add(nameField, gbc);

        // Tercera fila
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        formPanel.add(descLabel, gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 3;
        formPanel.add(descriptionField, gbc);

        // Cuarta fila
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        formPanel.add(priceLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(priceField, gbc);

        gbc.gridx = 2;
        formPanel.add(stockLabel, gbc);
        gbc.gridx = 3;
        formPanel.add(stockField, gbc);

        // Quinta fila
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(categoryLabel, gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 3;
        formPanel.add(categoryComboBox, gbc);

        // Panel de botones con fondo
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        buttonPanel.setBackground(UIConstants.LIGHT_GRAY);
        buttonPanel.add(saveButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(modifyStockButton);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 4;
        formPanel.add(buttonPanel, gbc);

        // Panel principal
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(UIConstants.LIGHT_GRAY);
        topPanel.add(titlePanel, BorderLayout.NORTH);
        topPanel.add(formPanel, BorderLayout.CENTER);
        
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(productTable), BorderLayout.CENTER);
    }

    private void setupListeners() {
        saveButton.addActionListener(e -> saveProduct());
        deleteButton.addActionListener(e -> deleteProduct());
        clearButton.addActionListener(e -> clearForm());
        modifyStockButton.addActionListener(e -> {
            int selectedRow = productTable.getSelectedRow();
            if (selectedRow >= 0) {
                try {
                    int id = (int) productTable.getValueAt(selectedRow, 0);
                    Product product = productController.findProduct(id);
                    if (product != null) {
                        showModifyStockDialog(product);
                    }
                } catch (SQLException ex) {
                    handleDatabaseError(ex);
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Por favor, seleccione un producto para modificar el stock",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        productTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = productTable.getSelectedRow();
                if (selectedRow >= 0) {
                    loadProductToForm(selectedRow);
                }
            }
        });
    }

    private void loadProducts() {
        try {
            List<Product> products = productController.getAllProducts();
            tableModel.setRowCount(0);
            for (Product product : products) {
                Object[] row = {
                    product.getId(),
                    product.getBarcode(),
                    product.getName(),
                    product.getDescription(),
                    formatter.format(product.getPrice()),
                    product.getStock(),
                    product.getCategory() != null ? product.getCategory().getName() : ""
                };
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void saveProduct() {
        try {
            if (nameField.getText().trim().isEmpty() || barcodeField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "El nombre y código son requeridos",
                    "Error de validación",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            Product product = new Product();
            if (!idField.getText().isEmpty()) {
                product.setId(Integer.parseInt(idField.getText()));
            }
            product.setBarcode(barcodeField.getText().trim());
            product.setName(nameField.getText().trim());
            product.setDescription(descriptionField.getText().trim());
            product.setPrice(Double.parseDouble(priceField.getText().replace(",", "")));
            product.setStock(Integer.parseInt(stockField.getText()));
            product.setCategory((Category) categoryComboBox.getSelectedItem());

            productController.saveProduct(product);
            JOptionPane.showMessageDialog(this,
                "Producto guardado exitosamente",
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadProducts();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Por favor, ingrese valores numéricos válidos para precio y stock",
                "Error de validación",
                JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void deleteProduct() {
        if (idField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un producto para eliminar",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        int response = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de eliminar este producto?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (response == JOptionPane.YES_OPTION) {
            try {
                productController.deleteProduct(Integer.parseInt(idField.getText()));
                JOptionPane.showMessageDialog(this,
                    "Producto eliminado exitosamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadProducts();
            } catch (SQLException ex) {
                handleDatabaseError(ex);
            }
        }
    }

    private void loadProductToForm(int row) {
        idField.setText(tableModel.getValueAt(row, 0).toString());
        barcodeField.setText(tableModel.getValueAt(row, 1).toString());
        nameField.setText(tableModel.getValueAt(row, 2).toString());
        descriptionField.setText(tableModel.getValueAt(row, 3).toString());
        priceField.setText(tableModel.getValueAt(row, 4).toString());
        stockField.setText(tableModel.getValueAt(row, 5).toString());

        try {
            int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
            Product product = productController.findProduct(id);
            if (product != null) {
                categoryComboBox.setSelectedItem(product.getCategory());
            }
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void clearForm() {
        idField.setText("");
        barcodeField.setText("");
        nameField.setText("");
        descriptionField.setText("");
        priceField.setText("");
        stockField.setText("");
        categoryComboBox.setSelectedIndex(0);
        productTable.clearSelection();
    }

    private void handleDatabaseError(SQLException ex) {
        JOptionPane.showMessageDialog(this,
            "Error de base de datos: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }

    private void showModifyStockDialog(Product product) {
        if (product == null) {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un producto primero",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Modificar Stock", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getContentPane().setBackground(UIConstants.LIGHT_GRAY);

        // Panel de contenido
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(UIConstants.LIGHT_GRAY);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);        // Información del producto
        JLabel productLabel = new JLabel("Producto", SwingConstants.LEFT);
        productLabel.setForeground(UIConstants.ACCENT_RED);
        JLabel productNameLabel = new JLabel(product.getName());
        gbc.gridx = 0; gbc.gridy = 0;
        contentPanel.add(productLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(productNameLabel, gbc);        JLabel currentStockLabel = new JLabel("Stock Actual", SwingConstants.LEFT);
        currentStockLabel.setForeground(UIConstants.ACCENT_RED);
        JLabel stockValueLabel = new JLabel(String.valueOf(product.getStock()));
        gbc.gridx = 0; gbc.gridy = 1;
        contentPanel.add(currentStockLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(stockValueLabel, gbc);

        JLabel newStockLabel = new JLabel("Nuevo Stock", SwingConstants.LEFT);
        newStockLabel.setForeground(UIConstants.ACCENT_RED);
        JTextField newStockField = new JTextField(10);
        newStockField.setText(String.valueOf(product.getStock()));
        gbc.gridx = 0; gbc.gridy = 2;
        contentPanel.add(newStockLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(newStockField, gbc);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(UIConstants.LIGHT_GRAY);        JButton saveButton = new JButton("Guardar");
        JButton cancelButton = new JButton("Cancelar");

        UIConstants.styleButton(saveButton);
        UIConstants.styleButton(cancelButton);

        saveButton.addActionListener(e -> {
            try {
                int newStock = Integer.parseInt(newStockField.getText().trim());
                if (newStock < 0) {
                    JOptionPane.showMessageDialog(dialog,
                        "El stock no puede ser negativo",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }

                product.setStock(newStock);
                productController.saveProduct(product);
                loadProducts();
                dialog.dispose();

                JOptionPane.showMessageDialog(this,
                    "Stock actualizado exitosamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog,
                    "Por favor ingrese un número válido",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                handleDatabaseError(ex);
            }
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        dialog.add(contentPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
}
