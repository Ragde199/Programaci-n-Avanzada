package com.pventa.model;

public class SaleItem {
    private int id;
    private Product product;
    private int quantity;
    private double subtotal;

    public SaleItem() {}

    public SaleItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
        calculateSubtotal();
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Product getProduct() { return product; }
    public void setProduct(Product product) { 
        this.product = product;
        calculateSubtotal();
    }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { 
        this.quantity = quantity;
        calculateSubtotal();
    }

    public double getSubtotal() { return subtotal; }

    private void calculateSubtotal() {
        if (product != null) {
            this.subtotal = product.getPrice() * quantity;
        }
    }
}
