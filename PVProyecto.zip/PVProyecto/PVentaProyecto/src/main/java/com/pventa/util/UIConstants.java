package com.pventa.util;

import javax.swing.*;
import java.awt.*;

public class UIConstants {
    // Colores principales
    public static final Color PRIMARY_RED = new Color(255, 99, 71);
    public static final Color SECONDARY_GRAY = new Color(240, 240, 240);
    public static final Color ACCENT_RED = new Color(220, 53, 69);
    public static final Color LIGHT_GRAY = new Color(249, 249, 249);
    public static final Color HOVER_COLOR = new Color(255, 220, 220);
    
    // Método para aplicar el aspecto visual común a un botón
    public static void styleButton(JButton button) {
        button.setBackground(SECONDARY_GRAY);
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        
        button.setFocusPainted(false);
        button.setBorderPainted(true);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY_RED, 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        button.setOpaque(true);
        
        // Efectos hover
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(HOVER_COLOR);
                button.setForeground(Color.BLACK);
            }
            
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(SECONDARY_GRAY);
                button.setForeground(Color.BLACK);
            }
        });
        
        // Asegurar tamaño mínimo
        Dimension preferredSize = button.getPreferredSize();
        preferredSize.width = Math.max(preferredSize.width, 150);
        preferredSize.height = Math.max(preferredSize.height, 35);
        button.setPreferredSize(preferredSize);
    }
    
    // Método para aplicar el aspecto visual común a una tabla
    public static void styleTable(JTable table) {
        table.setBackground(LIGHT_GRAY);
        table.setGridColor(SECONDARY_GRAY);
        table.getTableHeader().setBackground(PRIMARY_RED);
        table.getTableHeader().setForeground(Color.BLACK);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        table.setSelectionBackground(HOVER_COLOR);
        table.setSelectionForeground(Color.BLACK);
        table.setRowHeight(25);
    }
}
