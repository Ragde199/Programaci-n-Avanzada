package com.pventa.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Sale {
    private int id;
    private Date date;
    private double total;
    private double cashReceived;
    private double change;
    private List<SaleItem> items;

    public Sale() {
        this.date = new Date();
        this.items = new ArrayList<>();
        this.cashReceived = 0;
        this.change = 0;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public double getCashReceived() { return cashReceived; }
    public void setCashReceived(double cashReceived) {
        this.cashReceived = cashReceived;
        this.change = cashReceived - total;
    }

    public double getChange() { return change; }

    public List<SaleItem> getItems() { return items; }
    public void setItems(List<SaleItem> items) { this.items = items; }

    public void addItem(SaleItem item) {
        items.add(item);
        calculateTotal();
    }

    public void removeItem(SaleItem item) {
        items.remove(item);
        calculateTotal();
    }

    private void calculateTotal() {
        total = items.stream()
                .mapToDouble(item -> item.getQuantity() * item.getProduct().getPrice())
                .sum();
    }
}
