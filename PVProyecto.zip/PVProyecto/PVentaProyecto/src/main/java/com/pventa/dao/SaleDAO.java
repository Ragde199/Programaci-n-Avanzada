package com.pventa.dao;

import com.pventa.model.Sale;
import com.pventa.model.SaleItem;
import com.pventa.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SaleDAO {
    private DatabaseConnection dbConnection;
    private ProductDAO productDAO;

    public SaleDAO() {
        dbConnection = DatabaseConnection.getInstance();
        productDAO = new ProductDAO();
    }

    public void insert(Sale sale) throws SQLException {
        Connection conn = null;
        try {
            conn = dbConnection.getConnection();
            conn.setAutoCommit(false);

            // Insert sale
            String saleSql = "INSERT INTO Sales (date, total) VALUES (?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(saleSql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setTimestamp(1, new Timestamp(sale.getDate().getTime()));
                pstmt.setDouble(2, sale.getTotal());
                pstmt.executeUpdate();

                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        sale.setId(generatedKeys.getInt(1));
                    }
                }
            }

            // Insert sale items
            String itemSql = "INSERT INTO SaleItems (sale_id, product_id, quantity, subtotal) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(itemSql)) {
                for (SaleItem item : sale.getItems()) {
                    pstmt.setInt(1, sale.getId());
                    pstmt.setInt(2, item.getProduct().getId());
                    pstmt.setInt(3, item.getQuantity());
                    pstmt.setDouble(4, item.getSubtotal());
                    pstmt.executeUpdate();

                    // Update product stock
                    updateProductStock(conn, item.getProduct().getId(), item.getQuantity());
                }
            }

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void updateProductStock(Connection conn, int productId, int quantity) throws SQLException {
        String sql = "UPDATE Products SET stock = stock - ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, productId);
            pstmt.executeUpdate();
        }
    }

    public Sale findById(int id) throws SQLException {
        String sql = "SELECT * FROM Sales WHERE id = ?";
        Sale sale = null;
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    sale = new Sale();
                    sale.setId(rs.getInt("id"));
                    sale.setDate(rs.getTimestamp("date"));
                    sale.setTotal(rs.getDouble("total"));
                    sale.setItems(findSaleItems(sale.getId()));
                }
            }
        }
        return sale;
    }

    private List<SaleItem> findSaleItems(int saleId) throws SQLException {
        List<SaleItem> items = new ArrayList<>();
        String sql = "SELECT * FROM SaleItems WHERE sale_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, saleId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    SaleItem item = new SaleItem();
                    item.setId(rs.getInt("id"));
                    item.setProduct(productDAO.findById(rs.getInt("product_id")));
                    item.setQuantity(rs.getInt("quantity"));
                    items.add(item);
                }
            }
        }
        return items;
    }

    public List<Sale> findAll() throws SQLException {
        List<Sale> sales = new ArrayList<>();
        String sql = "SELECT * FROM Sales";
        
        try (Connection conn = dbConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Sale sale = new Sale();
                sale.setId(rs.getInt("id"));
                sale.setDate(rs.getTimestamp("date"));
                sale.setTotal(rs.getDouble("total"));
                sale.setItems(findSaleItems(sale.getId()));
                sales.add(sale);
            }
        }
        return sales;
    }    public void deleteAll() throws SQLException {
        String deleteSaleItemsSql = "DELETE FROM SaleItems; DBCC CHECKIDENT ('SaleItems', RESEED, 0)";
        String deleteSalesSql = "DELETE FROM Sales; DBCC CHECKIDENT ('Sales', RESEED, 0)";
        
        Connection conn = null;
        try {
            conn = dbConnection.getConnection();
            conn.setAutoCommit(false);

            // Primero eliminar los items de venta y reiniciar su contador
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(deleteSaleItemsSql);
            }

            // Luego eliminar las ventas y reiniciar su contador
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(deleteSalesSql);
            }

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
