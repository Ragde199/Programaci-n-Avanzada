package com.pventa.view;

import javax.swing.*;
import java.awt.*;
import com.pventa.util.UIConstants;

public class LoginView extends JFrame {
    private JTextField userField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton cancelButton;

    public LoginView() {
        setTitle("Iniciar Sesión");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 250);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(UIConstants.LIGHT_GRAY);

        initializeComponents();
        createLayout();
    }

    private void initializeComponents() {
        // Configurar campos de texto con estilo moderno
        userField = new JTextField(20);
        userField.setFont(new Font("Arial", Font.PLAIN, 14));
        userField.setBorder(BorderFactory.createCompoundBorder(
            userField.getBorder(), 
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));

        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            passwordField.getBorder(), 
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));        // Configurar botones con estilo consistente
        loginButton = new JButton("Iniciar Sesión");
        cancelButton = new JButton("Cancelar");
        
        UIConstants.styleButton(loginButton);
        UIConstants.styleButton(cancelButton);

        // Permitir usar Enter para iniciar sesión
        getRootPane().setDefaultButton(loginButton);

        loginButton.addActionListener(e -> attemptLogin());
        cancelButton.addActionListener(e -> System.exit(0));
    }

    private void createLayout() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(UIConstants.LIGHT_GRAY);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titleLabel = new JLabel("Bienvenido al Sistema");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(UIConstants.ACCENT_RED);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 5, 20, 5);
        mainPanel.add(titleLabel, gbc);

        // Restablecer gridwidth
        gbc.gridwidth = 1;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Usuario
        JLabel userLabel = new JLabel("Usuario:");
        userLabel.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0; gbc.gridy = 1;
        mainPanel.add(userLabel, gbc);
        gbc.gridx = 1;
        mainPanel.add(userField, gbc);

        // Contraseña
        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0; gbc.gridy = 2;
        mainPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        mainPanel.add(passwordField, gbc);

        // Panel de botones con estilo moderno
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(UIConstants.LIGHT_GRAY);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);

        // Agregar paneles al frame
        setLayout(new BorderLayout());
        add(mainPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void attemptLogin() {
        String username = userField.getText();
        String password = new String(passwordField.getPassword());

        // Por ahora, usaremos credenciales hardcodeadas. En una aplicación real,
        // esto debería verificarse contra una base de datos
        if (username.equals("admin") && password.equals("admin123")) {
            SwingUtilities.invokeLater(() -> {
                MainView mainView = new MainView();
                mainView.setVisible(true);
                dispose(); // Cerrar ventana de login
            });
        } else {
            JOptionPane.showMessageDialog(this,
                "Usuario o contraseña incorrectos",
                "Error de autenticación",
                JOptionPane.ERROR_MESSAGE);
            passwordField.setText("");
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
        });
    }
}
