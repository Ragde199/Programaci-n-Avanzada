package com.pventa.dao;

import com.pventa.model.Product;
import com.pventa.model.Category;
import com.pventa.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    private DatabaseConnection dbConnection;
    private CategoryDAO categoryDAO;

    public ProductDAO() {
        dbConnection = DatabaseConnection.getInstance();
        categoryDAO = new CategoryDAO();
    }

    public void insert(Product product) throws SQLException {
        String sql = "INSERT INTO Products (name, description, price, stock, barcode, category_id) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, product.getName());
            pstmt.setString(2, product.getDescription());
            pstmt.setDouble(3, product.getPrice());
            pstmt.setInt(4, product.getStock());
            pstmt.setString(5, product.getBarcode());
            
            if (product.getCategory() != null) {
                pstmt.setInt(6, product.getCategory().getId());
            } else {
                pstmt.setNull(6, java.sql.Types.INTEGER);
            }
            
            pstmt.executeUpdate();
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    product.setId(generatedKeys.getInt(1));
                }
            }
        }
    }

    public void update(Product product) throws SQLException {
        String sql = "UPDATE Products SET name = ?, description = ?, price = ?, stock = ?, barcode = ?, category_id = ? WHERE id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, product.getName());
            pstmt.setString(2, product.getDescription());
            pstmt.setDouble(3, product.getPrice());
            pstmt.setInt(4, product.getStock());
            pstmt.setString(5, product.getBarcode());
            
            if (product.getCategory() != null) {
                pstmt.setInt(6, product.getCategory().getId());
            } else {
                pstmt.setNull(6, java.sql.Types.INTEGER);
            }
            
            pstmt.setInt(7, product.getId());
            
            pstmt.executeUpdate();
        }
    }    public void delete(int id) throws SQLException {
        Connection conn = null;
        try {
            conn = dbConnection.getConnection();
            conn.setAutoCommit(false);

            // First, delete related SaleItems
            String deleteSaleItemsSql = "DELETE FROM SaleItems WHERE product_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteSaleItemsSql)) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();
            }

            // Then delete the product
            String deleteProductSql = "DELETE FROM Products WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteProductSql)) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();
            }

            // Reiniciar el contador de identidad si es el último producto
            String countSql = "SELECT COUNT(*) FROM Products";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next() && rs.getInt(1) == 0) {
                    try (Statement resetStmt = conn.createStatement()) {
                        resetStmt.execute("DBCC CHECKIDENT ('Products', RESEED, 0)");
                    }
                }
            }

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public Product findById(int id) throws SQLException {
        String sql = "SELECT * FROM Products WHERE id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToProduct(rs);
                }
            }
        }
        return null;
    }

    public Product findByBarcode(String barcode) throws SQLException {
        String sql = "SELECT * FROM Products WHERE barcode = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, barcode);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToProduct(rs);
                }
            }
        }
        return null;
    }

    public List<Product> findAll() throws SQLException {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM Products";
        
        try (Connection conn = dbConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                products.add(mapResultSetToProduct(rs));
            }
        }
        return products;
    }

    public List<Product> searchProducts(String query) throws SQLException {
        List<Product> results = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE LOWER(name) LIKE ? OR barcode LIKE ?";
        String searchPattern = "%" + query.toLowerCase() + "%";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product();
                    product.setId(rs.getInt("id"));
                    product.setName(rs.getString("name"));
                    product.setBarcode(rs.getString("barcode"));
                    product.setPrice(rs.getDouble("price"));
                    product.setStock(rs.getInt("stock"));
                    product.setCategory(categoryDAO.findById(rs.getInt("category_id")));
                    results.add(product);
                }
            }
        }
        return results;
    }

    private Product mapResultSetToProduct(ResultSet rs) throws SQLException {
        Product product = new Product();
        product.setId(rs.getInt("id"));
        product.setName(rs.getString("name"));
        product.setDescription(rs.getString("description"));
        product.setPrice(rs.getDouble("price"));
        product.setStock(rs.getInt("stock"));
        product.setBarcode(rs.getString("barcode"));
        
        int categoryId = rs.getInt("category_id");
        if (!rs.wasNull()) {
            Category category = categoryDAO.findById(categoryId);
            if (category != null) {
                product.setCategory(category);
            }
        }
        
        return product;
    }
}
