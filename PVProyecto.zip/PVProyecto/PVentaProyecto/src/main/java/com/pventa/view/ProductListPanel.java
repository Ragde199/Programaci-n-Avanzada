package com.pventa.view;

import com.pventa.controller.ProductController;
import com.pventa.model.Product;
import com.pventa.util.UIConstants;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class ProductListPanel extends JPanel {
    private JTable productTable;
    private DefaultTableModel tableModel;
    private ProductController productController;

    public ProductListPanel() {
        productController = new ProductController();
        initializeComponents();
        createLayout();
        loadProducts();
        setBackground(UIConstants.LIGHT_GRAY);
    }

    private void initializeComponents() {
        // Configurar la tabla con solo código y nombre
        String[] columnNames = {"Código", "Nombre"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        productTable = new JTable(tableModel);
        productTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        productTable.getTableHeader().setReorderingAllowed(false);
        UIConstants.styleTable(productTable);
    }

    private void createLayout() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel de título
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titlePanel.setBackground(UIConstants.LIGHT_GRAY);
        JLabel titleLabel = new JLabel("Productos Disponibles", SwingConstants.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(UIConstants.ACCENT_RED);
        titlePanel.add(titleLabel);

        add(titlePanel, BorderLayout.NORTH);
        add(new JScrollPane(productTable), BorderLayout.CENTER);
    }

    public void loadProducts() {
        try {
            List<Product> products = productController.getAllProducts();
            tableModel.setRowCount(0);
            for (Product product : products) {
                Object[] row = {
                    product.getBarcode(),
                    product.getName()
                };
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void handleDatabaseError(SQLException ex) {
        JOptionPane.showMessageDialog(this,
            "Error de base de datos: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }
}
