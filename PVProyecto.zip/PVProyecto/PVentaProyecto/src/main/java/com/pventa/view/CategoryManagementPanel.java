package com.pventa.view;

import com.pventa.controller.CategoryController;
import com.pventa.model.Category;
import com.pventa.util.UIConstants;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class CategoryManagementPanel extends JPanel {
    private JTable categoryTable;
    private DefaultTableModel tableModel;
    private CategoryController categoryController;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;

    public CategoryManagementPanel() {
        categoryController = new CategoryController();
        initializeComponents();
        createLayout();
        loadCategories();
        
        // Aplicar colores al panel principal
        setBackground(UIConstants.LIGHT_GRAY);
    }

    private void initializeComponents() {
        // Crear modelo de tabla
        String[] columns = {"ID", "Nombre", "Descripción"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        categoryTable = new JTable(tableModel);
        categoryTable.getColumnModel().getColumn(0).setMaxWidth(50);
        UIConstants.styleTable(categoryTable);        // Botones
        addButton = new JButton("Agregar");
        editButton = new JButton("Editar");
        deleteButton = new JButton("Eliminar");

        // Aplicar estilo a los botones
        UIConstants.styleButton(addButton);
        UIConstants.styleButton(editButton);
        UIConstants.styleButton(deleteButton);

        // Eventos
        addButton.addActionListener(e -> showCategoryDialog(null));
        editButton.addActionListener(e -> editSelectedCategory());
        deleteButton.addActionListener(e -> deleteSelectedCategory());
    }

    private void createLayout() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel de título
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titlePanel.setBackground(UIConstants.LIGHT_GRAY);
        JLabel titleLabel = new JLabel("Gestión de Categorías", SwingConstants.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(UIConstants.ACCENT_RED);
        titlePanel.add(titleLabel);

        // Panel de botones con fondo
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        buttonPanel.setBackground(UIConstants.LIGHT_GRAY);
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Panel superior combinado
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(UIConstants.LIGHT_GRAY);
        topPanel.add(titlePanel, BorderLayout.NORTH);
        topPanel.add(buttonPanel, BorderLayout.CENTER);

        // Agregar componentes
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(categoryTable), BorderLayout.CENTER);
    }

    private void loadCategories() {
        try {
            List<Category> categories = categoryController.getAllCategories();
            tableModel.setRowCount(0);
            for (Category category : categories) {
                Object[] row = {
                    category.getId(),
                    category.getName(),
                    category.getDescription()
                };
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void showCategoryDialog(Category category) {
        boolean isEdit = category != null;
        
        // Create the dialog
        Frame frame = JOptionPane.getFrameForComponent(this);
        JDialog dialog = new JDialog(frame, isEdit ? "Editar Categoría" : "Nueva Categoría", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getContentPane().setBackground(UIConstants.LIGHT_GRAY);

        // Create the form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(UIConstants.LIGHT_GRAY);
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

                // Name field with icon
        JLabel nameLabel = new JLabel("Nombre:", SwingConstants.LEFT);
        nameLabel.setForeground(UIConstants.ACCENT_RED);
        JTextField nameField = new JTextField(20);
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(nameLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(nameField, gbc);        // Description field
        JLabel descLabel = new JLabel("Descripción:", SwingConstants.LEFT);
        descLabel.setForeground(UIConstants.ACCENT_RED);
        JTextField descField = new JTextField(20);
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(descLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(descField, gbc);

        // Set existing values if editing
        if (isEdit) {
            nameField.setText(category.getName());
            descField.setText(category.getDescription());
        }

        // Create buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(UIConstants.LIGHT_GRAY);        JButton saveButton = new JButton("Guardar");
        JButton cancelButton = new JButton("Cancelar");

        // Aplicar estilo a los botones
        UIConstants.styleButton(saveButton);
        UIConstants.styleButton(cancelButton);

        // Add action listeners
        saveButton.addActionListener(e -> {
            try {
                String name = nameField.getText().trim();
                if (name.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog,
                        "El nombre es requerido",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Category cat = isEdit ? category : new Category();
                cat.setName(name);
                cat.setDescription(descField.getText().trim());
                
                categoryController.saveCategory(cat);
                loadCategories();
                dialog.dispose();
                JOptionPane.showMessageDialog(this,
                    "Categoría guardada exitosamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                handleDatabaseError(ex);
            }
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        // Add buttons to panel
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        // Add panels to dialog
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        // Configure and show dialog
        dialog.setSize(400, 200);
        dialog.setResizable(false);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

    private void editSelectedCategory() {
        int selectedRow = categoryTable.getSelectedRow();
        if (selectedRow >= 0) {
            try {
                int id = (int) categoryTable.getValueAt(selectedRow, 0);
                Category category = categoryController.findCategory(id);
                if (category != null) {
                    showCategoryDialog(category);
                }
            } catch (SQLException ex) {
                handleDatabaseError(ex);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione una categoría para editar",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedCategory() {
        int selectedRow = categoryTable.getSelectedRow();
        if (selectedRow >= 0) {
            int response = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de eliminar esta categoría?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

            if (response == JOptionPane.YES_OPTION) {
                try {
                    int id = (int) categoryTable.getValueAt(selectedRow, 0);
                    categoryController.deleteCategory(id);
                    loadCategories();
                    JOptionPane.showMessageDialog(this,
                        "Categoría eliminada exitosamente",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);
                } catch (SQLException ex) {
                    handleDatabaseError(ex);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione una categoría para eliminar",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDatabaseError(SQLException ex) {
        JOptionPane.showMessageDialog(this,
            "Error de base de datos: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }
}
