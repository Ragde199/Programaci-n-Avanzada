package com.pventa.view;

import com.pventa.controller.SaleController;
import com.pventa.controller.ProductController;
import com.pventa.model.Sale;
import com.pventa.model.SaleItem;
import com.pventa.model.Product;
import com.pventa.util.UIConstants;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class ReportsPanel extends JPanel {
    private JTable salesTable;
    private DefaultTableModel salesTableModel;
    private JTable detailsTable;
    private DefaultTableModel detailsTableModel;
    private SaleController saleController;
    private ProductController productController;
    private DecimalFormat formatter;
    private SimpleDateFormat dateFormat;
    private JButton clearSalesButton;
    private JButton productStatsButton;
    private JButton lowStockButton;

    public ReportsPanel() {
        saleController = new SaleController();
        productController = new ProductController();
        formatter = new DecimalFormat("#,##0.00");
        dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        
        initializeComponents();
        createLayout();
        loadSales();
        
        // Aplicar colores al panel principal
        setBackground(UIConstants.LIGHT_GRAY);
    }

    private void initializeComponents() {
        // Tabla de ventas
        String[] salesColumns = {"ID", "Fecha", "Total"};
        salesTableModel = new DefaultTableModel(salesColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        salesTable = new JTable(salesTableModel);
        salesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        UIConstants.styleTable(salesTable);

        // Tabla de detalles
        String[] detailsColumns = {"Producto", "Cantidad", "Precio", "Subtotal"};
        detailsTableModel = new DefaultTableModel(detailsColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        detailsTable = new JTable(detailsTableModel);
        UIConstants.styleTable(detailsTable);        // Botón de limpiar
        clearSalesButton = new JButton("Limpiar Ventas");
        UIConstants.styleButton(clearSalesButton);
        
        // Botón de estadísticas de productos
        productStatsButton = new JButton("Productos más/menos vendidos");
        UIConstants.styleButton(productStatsButton);
        
        // Botón de bajo stock
        lowStockButton = new JButton("Productos con bajo stock");
        UIConstants.styleButton(lowStockButton);

        // Botón de estadísticas de productos
        productStatsButton = new JButton("Estadísticas de Productos");
        UIConstants.styleButton(productStatsButton);

        // Botón de bajo stock
        lowStockButton = new JButton("Productos con Bajo Stock");
        UIConstants.styleButton(lowStockButton);
    }

    private void createLayout() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel superior con la tabla de ventas
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(UIConstants.LIGHT_GRAY);
        
        JPanel salesHeaderPanel = new JPanel(new BorderLayout());
        salesHeaderPanel.setBackground(UIConstants.LIGHT_GRAY);
        
        // Título
        JLabel titleLabel = new JLabel("Ventas Realizadas", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.BLACK);
          salesHeaderPanel.add(titleLabel, BorderLayout.CENTER);
        
        // Panel para los botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(UIConstants.LIGHT_GRAY);
        buttonPanel.add(productStatsButton);
        buttonPanel.add(lowStockButton);
        buttonPanel.add(clearSalesButton);
        
        salesHeaderPanel.add(buttonPanel, BorderLayout.EAST);
        topPanel.add(salesHeaderPanel, BorderLayout.NORTH);
        topPanel.add(new JScrollPane(salesTable), BorderLayout.CENTER);

        // Panel inferior con los detalles de la venta
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(UIConstants.LIGHT_GRAY);
        
        JPanel detailsHeaderPanel = new JPanel(new BorderLayout());
        detailsHeaderPanel.setBackground(UIConstants.LIGHT_GRAY);
        
        // Título de detalles
        JLabel detailsTitle = new JLabel("Detalles de la Venta", SwingConstants.CENTER);
        detailsTitle.setFont(new Font("Arial", Font.BOLD, 16));
        detailsTitle.setForeground(Color.BLACK);
        
        detailsHeaderPanel.add(detailsTitle, BorderLayout.CENTER);
        bottomPanel.add(detailsHeaderPanel, BorderLayout.NORTH);
        bottomPanel.add(new JScrollPane(detailsTable), BorderLayout.CENTER);

        // Split pane para dividir las dos tablas
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topPanel, bottomPanel);
        splitPane.setResizeWeight(0.5);
        splitPane.setBackground(UIConstants.LIGHT_GRAY);
        add(splitPane, BorderLayout.CENTER);        // Agregar listener al botón de limpiar
        clearSalesButton.addActionListener(e -> clearSalesTable());
        
        // Agregar listeners para los nuevos botones
        productStatsButton.addActionListener(e -> showProductStats());
        lowStockButton.addActionListener(e -> showLowStockProducts());

        // Listener para mostrar los detalles cuando se selecciona una venta
        salesTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = salesTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int saleId = Integer.parseInt(salesTable.getValueAt(selectedRow, 0).toString());
                    loadSaleDetails(saleId);
                }
            }
        });
    }

    public void updateReports() {
        SwingUtilities.invokeLater(() -> {
            // Primero cargar las ventas
            loadSales();
            
            // Luego manejar la selección
            int selectedRow = salesTable.getSelectedRow();
            if (selectedRow >= 0) {
                int saleId = Integer.parseInt(salesTable.getValueAt(selectedRow, 0).toString());
                loadSaleDetails(saleId);
            } else {
                detailsTableModel.setRowCount(0);
            }
            
            // Forzar un repintado de las tablas
            salesTable.repaint();
            detailsTable.repaint();
        });
    }

    private void loadSales() {
        try {
            List<Sale> sales = saleController.getAllSales();
            salesTableModel.setRowCount(0);
            for (Sale sale : sales) {
                Object[] row = {
                    sale.getId(),
                    dateFormat.format(sale.getDate()),
                    formatter.format(sale.getTotal())
                };
                salesTableModel.addRow(row);
            }
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void loadSaleDetails(int saleId) {
        try {
            Sale sale = saleController.findSale(saleId);
            detailsTableModel.setRowCount(0);
            
            if (sale != null) {
                for (SaleItem item : sale.getItems()) {
                    Object[] row = {
                        item.getProduct().getName(),
                        item.getQuantity(),
                        formatter.format(item.getProduct().getPrice()),
                        formatter.format(item.getSubtotal())
                    };
                    detailsTableModel.addRow(row);
                }
            }
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }    private void clearSalesTable() {
        try {
            int response = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de eliminar todas las ventas?\nEsta acción no se puede deshacer",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
                
            if (response == JOptionPane.YES_OPTION) {
                saleController.deleteAllSales();
                salesTableModel.setRowCount(0);
                detailsTableModel.setRowCount(0);
                JOptionPane.showMessageDialog(this,
                    "Todas las ventas han sido eliminadas",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }

    private void handleDatabaseError(SQLException ex) {
        JOptionPane.showMessageDialog(this,
            "Error de base de datos: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }

    private void showProductStats() {
        try {
            List<Sale> sales = saleController.getAllSales();
            Map<String, Integer> productSales = new HashMap<>();
            
            // Contar ventas por producto
            for (Sale sale : sales) {
                for (SaleItem item : sale.getItems()) {
                    String productName = item.getProduct().getName();
                    productSales.merge(productName, item.getQuantity(), Integer::sum);
                }
            }
            
            if (productSales.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "No hay datos de ventas para mostrar estadísticas.",
                    "Sin datos",
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Encontrar producto más y menos vendido
            Map.Entry<String, Integer> maxEntry = Collections.max(productSales.entrySet(), Map.Entry.comparingByValue());
            Map.Entry<String, Integer> minEntry = Collections.min(productSales.entrySet(), Map.Entry.comparingByValue());
            
            StringBuilder message = new StringBuilder();
            message.append("Estadísticas de Ventas:\n\n");
            message.append("Producto más vendido:\n");
            message.append(String.format("- %s: %d unidades\n\n", maxEntry.getKey(), maxEntry.getValue()));
            message.append("Producto menos vendido:\n");
            message.append(String.format("- %s: %d unidades", minEntry.getKey(), minEntry.getValue()));
            
            JOptionPane.showMessageDialog(this,
                message.toString(),
                "Estadísticas de Productos",
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }
    
    private void showLowStockProducts() {
        try {
            List<Product> lowStockProducts = productController.getLowStockProducts(5); // umbral de 5 unidades
            
            if (lowStockProducts.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "No hay productos con bajo stock.",
                    "Stock Normal",
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            StringBuilder message = new StringBuilder();
            message.append("Productos con Stock Bajo (menos de 5 unidades):\n\n");
            
            for (Product product : lowStockProducts) {
                message.append(String.format("- %s: %d unidades\n", 
                    product.getName(), product.getStock()));
            }
            
            JOptionPane.showMessageDialog(this,
                message.toString(),
                "Alerta de Stock",
                JOptionPane.WARNING_MESSAGE);
                
        } catch (SQLException ex) {
            handleDatabaseError(ex);
        }
    }
}
