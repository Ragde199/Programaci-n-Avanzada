-- Create database
CREATE DATABASE PVentaDB;
GO

USE PVentaDB;
GO

-- Create Categories table
CREATE TABLE Categories (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(255)
);

-- Create Products table
CREATE TABLE Products (
    id INT IDENTITY(1,1) PRIMARY KEY,    barcode VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES Categories(id)
);

-- Create Sales table
CREATE TABLE Sales (
    id INT IDENTITY(1,1) PRIMARY KEY,
    date DATETIME NOT NULL DEFAULT GETDATE(),
    total DECIMAL(10,2) NOT NULL
);

-- Create SaleItems table
CREATE TABLE SaleItems (
    id INT IDENTITY(1,1) PRIMARY KEY,
    sale_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES Sales(id),
    FOREIGN KEY (product_id) REFERENCES Products(id)
);

-- Create indexes
CREATE INDEX idx_product_barcode ON Products(barcode);
CREATE INDEX idx_sale_date ON Sales(date);
CREATE INDEX idx_saleitem_sale ON SaleItems(sale_id);
CREATE INDEX idx_saleitem_product ON SaleItems(product_id);
