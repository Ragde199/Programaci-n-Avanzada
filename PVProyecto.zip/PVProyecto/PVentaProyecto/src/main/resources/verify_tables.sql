USE PVentaDB;
GO

-- Verificar si existe la tabla Categories
SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Categories';

-- Verificar si existe la columna category_id en Products
SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Products' AND COLUMN_NAME = 'category_id';

-- Verificar estructura completa de Products
SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Products';
