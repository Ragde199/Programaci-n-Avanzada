-- Create Categories table and update Products table
USE PVentaDB;
GO

-- Create Categories table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Categories]') AND type in (N'U'))
BEGIN
    CREATE TABLE Categories (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        description VARCHAR(255)
    );
END
GO

-- Add category_id column to Products if it doesn't exist
IF NOT EXISTS(SELECT * FROM sys.columns 
    WHERE Name = N'category_id' AND Object_ID = Object_ID(N'Products'))
BEGIN
    ALTER TABLE Products ADD category_id INT;
    ALTER TABLE Products ADD CONSTRAINT FK_Products_Categories 
        FOREIGN KEY (category_id) REFERENCES Categories(id);
END
GO
